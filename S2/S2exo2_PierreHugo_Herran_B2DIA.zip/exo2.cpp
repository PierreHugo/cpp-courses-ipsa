#include<iostream>
#include"note_class.h"
#include"date_class.h"
#include"etudiant_class.h"
#include"classe_class.h"

//--------------------
// Exo 2
//--------------------
main()
{
    classe Bachelor2;
    Bachelor2.ajouter();
    Bachelor2.calcul_moyenne_classe();
    Bachelor2.tri_etud();
    Bachelor2.afficher();
}

